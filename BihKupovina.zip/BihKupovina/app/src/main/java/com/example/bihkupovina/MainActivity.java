package com.example.bihkupovina;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class MainActivity extends AppCompatActivity {
    public static Intent homeIntent;
    private static int SPLASH_TIME_OUT = 1700;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        final boolean b = new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                homeIntent = new Intent(MainActivity.this, app.class);
                startActivity(homeIntent);
                finish();
            }
        },SPLASH_TIME_OUT);
    }
}